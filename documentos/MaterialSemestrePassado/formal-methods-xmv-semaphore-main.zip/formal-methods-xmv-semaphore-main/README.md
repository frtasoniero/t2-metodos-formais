# formal-methods-xmv-semaphore

## Running the dev env (these academic tools suck)

```bash
make start
../nuXmv ./FILE_NAME
```

All the files from ./source are binded to the container